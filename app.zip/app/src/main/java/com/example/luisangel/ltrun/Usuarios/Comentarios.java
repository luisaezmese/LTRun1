package com.example.luisangel.ltrun.Usuarios;


public class Comentarios {
    String comentarios;

    public Comentarios() {


    }


    public Comentarios(String comentarios) {
        this.comentarios = comentarios;
        ;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setId(String id) {
        this.comentarios = comentarios;
    }
}
