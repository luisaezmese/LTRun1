package com.example.luisangel.ltrun.Usuarios;

/**
 * Created by LuisAngel on 04/05/2017.
 */

public class FirebaseReferences {

    final public static String USUARIO_REFERENCE = "Usuarios";
    final public static String NOTICIAS_REFERENCE = "Noticia";
    final public static String COMENTARIOS_REFERENCE = "Comentarios";
    final public static String TOTAL_REFERENCE = "ltrun-99027";


}
